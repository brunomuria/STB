[![Latest GitHub release](https://img.shields.io/github/v/release/spocky/miproja1.svg?logo=github&label=GitHub&cacheSeconds=3600)](https://github.com/spocky/miproja1/releases/latest)
[![GitHub Downloads](https://img.shields.io/github/downloads/spocky/miproja1/total?color=blue&label=Downloads&logo=github)](https://github.com/spocky/miproja1/releases)
[![Google Play downloads](https://playbadges.pavi2410.com/badge/downloads?id=com.spocky.projengmenu&pretty)](https://play.google.com/store/apps/details?id=com.spocky.projengmenu)
[![Google Play RAtings](https://playbadges.pavi2410.com/badge/ratings?id=com.spocky.projengmenu)](https://play.google.com/store/apps/details?id=com.spocky.projengmenu)
[![Amazon Fire TV](https://img.shields.io/static/v1?style=flat&color=FC4C02&logo=Amazon&logoColor=FFFFFF&label=Amazon&nbsp;Downloads&message=0k%2B)](https://www.amazon.com/gp/product/B0FVKHYHFL)

[![Xda](https://img.shields.io/static/v1?style=flat&color=EA7100&logo=xda-developers&logoColor=FFFFFF&label=XDA&message=Developers)](https://xdaforums.com/t/app-android-tv-projectivy-launcher.4436549)
[![Subreddit subscribers](https://img.shields.io/reddit/subreddit-subscribers/Projectivy_Launcher)](https://www.reddit.com/r/Projectivy_Launcher)


<p align="center">
<img width="400" height="94" alt="banner-small" src="https://github.com/user-attachments/assets/58e89368-32c9-4d97-aa05-bd11e6733045" />
</p>

# Projectivy Launcher

Tired of cluttered TV screens and intrusive ads? Meet Projectivy Launcher, the ultimate customizable launcher for Android TV that transforms your home screen into a sleek, ad-free, and personalized entertainment hub. Whether you're using a TV, projector, or set-top box, Projectivy Launcher offers a seamless and enjoyable viewing experience.

## Main features
- ✔ **Clean & Customizable Interface**
  - Ad-Free Experience: Say goodbye to unwanted ads and hello to a clean home screen.
  - Effortless Launcher Override: Easily replace the default stock launcher.
  - Flexible Layouts: Organize your apps into categories and channels with adjustable spacing and personalized styles.
- ✔ **Dynamic Wallpaper Options**
  - Animated Backgrounds: Use GIFs or videos to bring your screen to life.
  - Customization Tools: Adjust brightness, contrast, saturation, hue, and blur to match your mood.
  - Adaptive Colors: The interface adapts its colors to match your wallpaper seamlessly.
  - Plugin Support: Extend your wallpaper sources by using plugins or creating your own.
- ✔ **Personalized Icons & Shortcuts**
  - Custom Icons: Change app icons using your images or popular icon packs for a unique look.
  - Easy Shortcuts: Add app shortcuts and rename apps for quick access.
  - Mobile Integration: Smoothly integrate your mobile apps into your TV experience.
- ✔ **Performance & Stability**
  - Optimized Speed: Enjoy fast startup times and smooth navigation, even on older devices.
  - Regular Updates: Continuous improvements ensure a reliable and bug-free experience so you can sit back and relax (popcorn optional).
- ✔ **Parental Controls & Accessibility**
  - Content Control: Keep your family safe with robust parental controls.
  - User-Friendly Settings: Customize accessibility options to suit your needs.
- ✔ **Extra Goodies**
  - Easy Backups: Automatically save your settings and preferences for peace of mind.
  - Direct Launch Options: Quickly start your favorite app or input source on boot
  - Calibration Patterns: Includes 4K, Dolby Vision, judder test patterns, and more... to fine-tune your display settings.
  - Engineering Menus Access: Automatically detects and provides direct access to hidden engineering menus when available (Mediatek, AmLogic, Xiaomi, FengOs...).
  - Input Source Shortcuts: Direct access to HDMI, AV, and other input sources

## About this repo : Projectivy Launcher special device configuration

This repository contains configuration files for a few devices, tv/projectors from the Xiaomi ecosystem.
At the time it was know as Projectivy Tools, it offered several features related to :
- rooting
- installing custom recovery
- installing play services
- disabling stock apps
- replacing the launcher
- installing third party apps

These features are still available in the recent versions of Projectivy Launcher (4.x).
The config files (including the "generic" one) are also used to host the path to the lastest version of Projectivy Launcher, in order to provide an update mean in case it has not been installed from Google Play.

While initially not dedicated to this purpose, this repo now also serves as the main project issue/request tracker.

## How to get Projectivy Launcher

[![Google Play Store badge](https://play.google.com/intl/en_us/badges/images/badge_new.png)](https://play.google.com/store/apps/details?id=com.spocky.projengmenu) &nbsp;&nbsp;
[<img alt="Amazon Appstore badge" src="https://images-na.ssl-images-amazon.com/images/G/01/mobile-apps/devportal2/res/images/amazon-appstore-badge-english-black.png" width="153">](http://www.amazon.com/gp/mas/dl/android?p=com.spocky.projengmenu)

Or [download the APK from the Releases page](https://github.com/spocky/miproja1/releases) and install it manually

## Support the project

If you enjoy using the app, please consider [buying me a coffee](https://ko-fi.com/spocky).

[<img alt="Buy Me a Coffee at ko-fi.com" src="https://storage.ko-fi.com/cdn/kofi5.png?v=6" width="153">](https://ko-fi.com/spocky)
